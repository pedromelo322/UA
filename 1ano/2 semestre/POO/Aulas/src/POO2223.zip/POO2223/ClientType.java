public enum ClientType {
    MEMBER, NORMAL
}
